import 'package:flutter/material.dart';

class MyApp2 extends StatefulWidget {
  
  Map data={};
  
  MyApp2(this.data);

  @override
  State<MyApp2> createState() => _MyApp2State();
}

class _MyApp2State extends State<MyApp2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text(widget.data['name']),),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Center(
          child: Align(
              alignment:Alignment.center,
            child: Text(widget.data['des'],style: TextStyle(fontSize: 30),)),
        ),
      ),
    );
  }
}
